ZSCALER ARCHITECTURE STENCIL LIBRARY  (v3 — tight bounding boxes)
================================================================

27 shapes, one visual system, transparent background, spec'd to Zscaler docs.
Each shape's box (viewBox / cell) is now cropped tight to the artwork, so in
draw.io and Visio the connection points and labels sit right on the shape with
no floating gap.

FORMATS
  zscaler-stencils.drawio-library.xml   draw.io / diagram.net library  <-- USE THIS for diagram.net
  zscaler-stencils.html                 interactive gallery (search, copy, drag, download)
  zscaler-stencils.vsdx                 Visio drawing (desktop Visio)
  /svg   27 vector shapes, transparent, tight viewBox
  /png   27 raster shapes, ~1024px long edge, transparent, tight crop
  /logo  cleaned Zscaler mark (cyan + white)

DIAGRAM.NET, TRANSPARENT, WITH TIGHT CONNECTION BOXES
  1. https://app.diagrams.net  ->  File > Open Library...  ->  zscaler-stencils.drawio-library.xml
  2. Drag a shape from the left panel onto the canvas.
  3. Hover a shape edge to pull a connector — the box hugs the art, so lines
     attach cleanly with no gap. Double-clicking adds a label right under it.
  (Clipboard copy is blocked inside preview panes; open the .html in a real
  browser TAB if you want the Copy PNG / drag-to-canvas options.)

COMPONENTS
  Zscaler Zero Trust : Zero Trust Exchange, Central Authority, Public Service Edge,
                       Private Service Edge, Virtual Service Edge, App Connector,
                       Application Segment, Client Connector, Identity Provider,
                       Log Streamer (NSS/LSS), Cloud Connector, Branch Connector,
                       Cloud Browser Isolation, Zscaler Cloud
  Business Continuity: Private Cloud Controller, Private Cloud,
                       Business Continuity Cloud, DR PAC File
  Network / DC       : Public IP, Private IP, Internal Application, Data Center,
                       SIEM, Security Zone / DMZ, Internet, Firewall, User/Endpoint

NOTE
  Generic stencils for your own architecture docs. "Zscaler" and the mark are
  trademarks of Zscaler, Inc.; for brand-accurate assets use Zscaler's official
  icon set. Logo rebuilt from the image you supplied.
